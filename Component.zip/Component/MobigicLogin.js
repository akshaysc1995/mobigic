import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

export default function MobigicLogin()
{
  const navigate = useNavigate();
  const location = useLocation();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  function usernameHandler(e) {
      let item = e.target.value;
      setUsername(item);
  }

  function passwordHandler(e) {
      let item = e.target.value;
      setPassword(item);
  }
  
 

  function login() {
      let user = {
          emailId: username,
          password: password
      }
      axios.post("http://localhost:8080/login", user).then((response) => {
       
        localStorage.setItem("user",JSON.stringify(response.data))
        
        

        console.log(response.data);
        if(response.data.user_name==user.emailId){
            console.log(true);
            navigate("/welcomeuser");
        }else{
            alert("You don't have any account, Please signUp");
        navigate("/signUp");
        }
       
    }).catch((error) => {
        console.log(error);
        alert("You don't have any account, Please signUp");
        navigate("/signUp");
  })
}


  /*------------------------------------------------------------------------*/

return (
  <div className='login'>
               <div className='p1'>
                 <br></br>
                 <div className="container">
                   <div className='row'>
                     <div className="card col-md-6 offset-md-3 offset-md-3" style={{ backgroundColor: "transparent" }}>
                       <h1 className='text-center' style={{ color: "Black" }} >LOG-IN</h1>
                       <div className='card-body'>
            
                    <div className="mb-1">
                    
                    <label style={{ color: "Black" }}>Email Id:</label>
                        <input
                            className="form-control form-control-lg"
                            type="text"
                            placeholder="Enter Email"
                            value={username}
                            
                            onChange={usernameHandler}
                           
                        />
                      <br/>
                       
                    </div>
                    <div className="mb-1">
                    <label style={{ color: "Black" }}>Password:</label>
                        <input
                            className="form-control form-control-lg"
                            type="password"
                            placeholder="Enter Password"
                            onChange={passwordHandler}
                        />
                        <br/>
                        
                    </div>
                    <div className="mb-1">
                        <center>
                           
                            <button
                                className="btn btn-success btn-lg w-75"
                                onClick={login}
                            >
                                LOGIN
                            </button>
                           
                        </center>
                    </div>
                    <div className="text-center">
                        <Link to="/signUp" className="text-dark">
                           
                        </Link>
                    </div>
                    {/* </form> */}
                </div>
            </div>
        </div>
        </div>
        </div>
        </div>
    );
}

