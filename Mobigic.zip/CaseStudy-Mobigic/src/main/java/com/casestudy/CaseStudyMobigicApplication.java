package com.casestudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaseStudyMobigicApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaseStudyMobigicApplication.class, args);
	}

}
