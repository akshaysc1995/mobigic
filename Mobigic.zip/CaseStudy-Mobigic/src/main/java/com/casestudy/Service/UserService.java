package com.casestudy.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.Entity.User;
import com.casestudy.Repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public User login(User user) {
			// TODO Auto-generated method stub
			return userRepository.findByUserNameAndPassword(user.getUserName(), user.getPassword());
		}
	}
